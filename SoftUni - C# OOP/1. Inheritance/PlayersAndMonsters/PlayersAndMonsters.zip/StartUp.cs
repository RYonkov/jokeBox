﻿using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        static void Main()
        {
            Knight kn = new Knight("Rado", 19);
            Console.WriteLine(kn);
        }
    }
}
