using NUnit.Framework;
using System;

namespace RepairShop.Tests
{
    public class Tests
    {
        public class RepairsShopTests
        {
            [Test]
            public void WhetherTheContructorIsCorrect()
            {
                //Arrange
                const string GARAGE_NAME = "Yassen";
                const int NUMBER_OF_MECHANICS = 5;
                
                //Act               
                Garage garage = new Garage(GARAGE_NAME, NUMBER_OF_MECHANICS);

                //Assert
                Assert.AreEqual(GARAGE_NAME, garage.Name);
                Assert.That(garage.Name, Is.EqualTo(GARAGE_NAME));


                Assert.AreEqual(NUMBER_OF_MECHANICS, garage.MechanicsAvailable);
                Assert.AreEqual(0, garage.CarsInGarage);                
            }

            [Test]
            public void WhetherExceptionsIsThrownIfGarageNameIsNullOrEmpty()
            {             
                //Assert
                Assert.Throws<ArgumentNullException>(() =>
                {
                    var garage1 = new Garage(null, 10);
                }, "Invalid garage name.");

                Assert.Throws<ArgumentNullException>(() =>
                {
                    var garage1 = new Garage(String.Empty, 10);
                }, "Invalid garage name.");

            }

            [Test]
            public void WhetherExceptionIsThrownInCaseNoAvailableMechanics()
            {
                //Assert
                Assert.Throws<ArgumentException>(() =>
                {
                    var garage = new Garage("Yassen", 0);
                }, "At least one mechanic must work in the garage.");
                
            }

            [Test]
            public void WhetherExceptionIsThrownInCaseOfNoAvailableMechanics()
            {
                
                //Arrange
                Car car = new Car("Skoda", 3);
                Car secondCar = new Car("BMW", 5);
                Garage garage = new Garage("Yassen", 1);

                //Act
                garage.AddCar(car);

                //Assert               
                Assert.Throws<InvalidOperationException>(() =>
                {
                    garage.AddCar(secondCar);
                }, "No mechanic available.");
            }

            [Test]
            public void WhetherAddingACarIncrementCounter()
            {

                //Arrange
                Car car = new Car("Skoda", 3);
                Car secondCar = new Car("BMW", 5);
                Garage garage = new Garage("Yassen", 1);

                //Act
                garage.AddCar(car);

                //Assert
                Assert.AreEqual(1, garage.CarsInGarage);

            }

        }
    }
}