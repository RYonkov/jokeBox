namespace Database.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class DatabaseTests
    {
        [Test]
        public void Whether_New_Element_Is_Added_Propertly()
        {
            Database db = new Database();           
            int n = db.Count;
            if (n!=16)
            {
                db.Add(1);
            }           
            Assert.AreEqual(n+1, db.Count);
        }
        [Test]
        public void Whether_Exception_Is_Thrown_When_New_Element_Is_Added_To_Position_17()
        {
            Database db = new Database();
            for (int i = 0; i < 16; i++)
            {
                db.Add(i);
            }
            int n = db.Count;
            if (n == 16)
            {
                Assert.Throws<InvalidOperationException>(() => db.Add(1));
            }           
        }
        [Test]
        public void Whether_Last_Element_Is_Removed()
        {
            Database db = new Database();
            int n = db.Count;
            if (n > 0)
            {
                db.Remove(); 
                Assert.AreEqual(n - 1, db.Count);
            }           
        }
        [Test]
        public void Whether_Last_Element_Is_Tried_To_Removed_From_Empty_DB()
        {
            Database db = new Database();
            int n = db.Count;
            for (int i = 0; i < n; i++)
            {
                db.Remove();
            }
            if (n == 0)
            {
                Assert.Throws<InvalidOperationException>(() => db.Remove());                
            }
        }
        [Test]
        public void Whether_The_Constructor_Takes_Only_Integers()
        {
            int[] initialArray = new int[] { 1, 3, 6 };
            Database db = new Database(initialArray);           
        }
        [Test]
        public void Whether_The_Fetch_Command_Works()
        {
            int[] initialArray = new int[] { 1, 3, 6 };
            Database db = new Database(initialArray);
            object copyArray = db.Fetch();
            Assert.AreEqual(initialArray, copyArray);
        }
    }
}
