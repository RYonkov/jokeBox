﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IBirthday
    {
        public string BirthDate { get; set; }       
    }
}
